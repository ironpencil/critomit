<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Taint" tilewidth="32" tileheight="32">
 <image source="Taint.png" width="1248" height="192"/>
</tileset>
