<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Pit" tilewidth="32" tileheight="32">
 <image source="Pit.png" width="416" height="32"/>
</tileset>
